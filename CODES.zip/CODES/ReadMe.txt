
Sense-Aid DataCollector2
I-Ta Lee 
lee2226@purdue.edu

This is a tool designed for collecting battery and cellular information from Android smartphones.


Minimum Android API Level: 

18 


Compilation:

Please use eclipse and open this folder as an eclipse project. Then, you can easily compile the project.


Usage:

Just click “start” button then it will start collecting data.


ToDo:

upload log file.



